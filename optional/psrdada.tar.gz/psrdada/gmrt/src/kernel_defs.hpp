
#pragma once

enum { CUDA_MAX_GRID_SIZE = 65535,
       CUDA_WARP_SIZE     = 32 };

typedef unsigned int gpu_size_t;
