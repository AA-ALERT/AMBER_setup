<?PHP
include("../definitions_i.php");
include("../functions_i.php");
?>
<HTML>
<HEAD>
  <TITLE>APSR | Controls</TITLE>
</HEAD>
<FRAMESET COLS="1" ROWS="480px,*" border=1 bordercolor="black">
  <FRAME name="control" src="control.php" frameborder=0 marginheight=0 marginwidth=0></FRAME>
  <FRAME name="output" src=""></FRAME>
</FRAMESET>
</HTML>
